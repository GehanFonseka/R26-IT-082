---
title: CV Match - Browser App
emoji: "📄"
colorFrom: indigo
colorTo: purple
sdk: static
pinned: false
---

# CV Match - Browser App

Upload a PDF, DOCX or TXT CV, review the extracted fields, and score it against a job description.

This free static Space runs CV text extraction and model scoring in the visitor's browser. CV files are not uploaded to an application server. The browser downloads and caches the public ONNX model from [`Gehan77/cv-match-browser`](https://huggingface.co/Gehan77/cv-match-browser) on first use.

The result is an assistive ranking signal only. Always review the original CV and job requirements before making a hiring decision.
